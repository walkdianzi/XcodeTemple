//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - Life Cycle
- (void)viewDidLoad{
    
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    //Notification
}

- (void)dealloc{
    
    
}

#pragma mark - Layout

- (void)viewWillLayoutSubviews{
    
    [super viewWillLayoutSubviews];
}

#pragma mark - Delegate


#pragma mark - KVO Or Notification


#pragma mark - Event Response


#pragma mark - Private Methon


#pragma mark - Getter and Setter

@end
