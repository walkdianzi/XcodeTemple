//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "___VARIABLE_cocoaSubclass___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaSubclass___

#pragma mark- model

#pragma mark- view

#pragma mark- methon

@end
