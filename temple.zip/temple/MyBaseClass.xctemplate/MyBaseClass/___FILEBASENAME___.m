//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAME___ ()

@end

@implementation ___FILEBASENAME___

#pragma mark - Init

- (instancetype)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)dealloc{
    
    
}

#pragma mark - Layout

-(void)layoutSubviews{
 
    [super layoutSubviews];
}

#pragma mark - Private Methon


#pragma mark - KVO Or Notification


#pragma mark - Delegate Or DataSource


#pragma mark - Getter and Setter

@end
